

function register(data){


}

function login(data){


}

module.exports = {
    register,
    login
};